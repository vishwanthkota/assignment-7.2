package com.example.myapplication.intentcontact;

import android.content.Intent;
import android.net.Uri;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button opencontact=(Button) findViewById(R.id.button2);
        //do other activity with other button
        //Button openactivity=(Button) findViewById(R.id.button);
        //given openWebPage linking with the
        opencontact.setOnClickListener(this);
        //openactivity.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        //creating an intent i.e is webintent giving an URL for it
        //Action view for opening an web activity .there are many intent for every activy
        Intent contactintent = new Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI);
        Toast.makeText(getApplicationContext(),"opening contacts",Toast.LENGTH_LONG).show();
        startActivity(contactintent);
    }
}
